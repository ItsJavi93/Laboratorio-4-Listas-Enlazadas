package lab.listas.enlazadas;
import lab.listas.enlazadas.Nodo;
/**
 *
 * @author javie
 */
public class LinkedStack<T> implements StackYV<T>{
    private Nodo<T> cabeza;
    private int tamaño;
    
    public void Push(T elemento){//Ingresa un elemento a la pila
        cabeza = new Nodo<>(elemento, cabeza);
        tamaño++;
    }
    
    public T Pop(){ //Elimina el elemento tope de la pila
        if(IsEmpty()){
            System.out.println("Error: La pila esta vacía");
            System.out.println("Pruebe añadiendo un elemento con el metodo Push(elemento)");
        }
        
        T element = cabeza.getElemento();
        cabeza = cabeza.getSiguiente();
        tamaño--;
        return element;
    }
    
    public T EliminarEnPosicion(int posicion){ //Guarda el contenido del nodo seleccionado y lo elimina en la posicion que este
        if(posicion < 0 || posicion > Size()){
            System.out.println("Error: Posicion invalida");
        }
        T valor;
        if(posicion == 0){
            valor = this.Pop();
        } else{
            Nodo<T> actual = this.cabeza;
            Nodo<T> anterior = null;
            int i = 0;
            while(i < posicion){
                anterior = actual;
                actual = actual.getSiguiente();
                i++;
            }
            valor = actual.getElemento();
            anterior.setSiguiente(actual.getSiguiente());            
        }       
        tamaño--;
        return valor;
    }
    
    public T Top(){
        if(IsEmpty()){
            System.out.println("Error: La pila esta vacía");
            System.out.println("Pruebe añadiendo un elemento con el metodo Push(elemento)");
        }
        
        return cabeza.getElemento();
    }
    
    public boolean IsEmpty(){
        return cabeza == null;
    }
    
    public int Size(){
        return tamaño;
    }
}
