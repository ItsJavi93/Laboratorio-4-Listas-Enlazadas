package lab.listas.enlazadas;

/**
 *
 * @author javie
 */
public class Nodo<T> {
    private T elemento;
    private Nodo<T> siguiente;
    
    public Nodo(T elemento, Nodo<T> siguiente){
        this.elemento = elemento;
        this.siguiente = siguiente;
    }
    
    public void setElemento(T elemento){
        this.elemento = elemento;      
    }
    
    public void setSiguiente(Nodo<T> siguiente){
        this.siguiente = siguiente;
    }
    
    public T getElemento(){
        return elemento;
    }
    
    public Nodo<T> getSiguiente(){
        return siguiente;
    }
}
