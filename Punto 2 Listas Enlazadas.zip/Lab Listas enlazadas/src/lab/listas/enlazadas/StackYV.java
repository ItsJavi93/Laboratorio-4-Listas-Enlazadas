package lab.listas.enlazadas;

/**
 *
 * @author javie
 */
public interface StackYV<T>{
    public void Push(T elemento);
    T Pop();
    T EliminarEnPosicion(int posicion);
    T Top();
    boolean IsEmpty();
    int Size();
}
